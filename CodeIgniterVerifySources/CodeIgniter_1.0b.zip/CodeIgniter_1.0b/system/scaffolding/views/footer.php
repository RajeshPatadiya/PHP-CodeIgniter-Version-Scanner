
</div>

<div id="footer">
<p><a href="http://www.codeigniter.com/">Code Igniter</a>, by <a href="http://www.pmachine.com">pMachine</a> -  Version <?php echo APPVER ?></p>
<p>Page rendered in <?php echo $this->benchmark->elapsed_time(); ?></p>
</div>

</body>
</html>